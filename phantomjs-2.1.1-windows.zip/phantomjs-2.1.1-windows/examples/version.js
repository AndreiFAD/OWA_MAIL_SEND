"use strict";
console.log('using PhantomJS version ' +
  phantom.version.major + '.' +
  phantom.version.minor + '.' +
  phantom.version.patch);
phantom.exit();
